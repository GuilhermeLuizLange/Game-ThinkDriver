package br.com.thinkdriver;

import java.util.List;

public class GameConf {
	boolean isNewQuestion, isFinished, contScore, contBarrier, isHit;
	int frame_x, 
		frame_y, 
		nOpponent,
		qtdOpponent,
		score, 
		highScore, 
		sceneController,
		phase,
		aswerWay,
		threadSleep,
		threadCont;
	long initial_time, time_response, isHitInitialTime, isHitRealTime, hitController, last_OpponentCar;
	List<Integer> ways;
}
