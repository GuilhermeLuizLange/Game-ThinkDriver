package br.com.thinkdriver;

public class Car {
	public int pos_x, pos_y, speed_y, speed_x;
	public String imagemLoc, imagemLocOpaco;
	public long car_id;
}
